# Resume

A Pen created on CodePen.io. Original URL: [https://codepen.io/umarcbs/pen/bGedPMK](https://codepen.io/umarcbs/pen/bGedPMK).

Personal Resume/CV